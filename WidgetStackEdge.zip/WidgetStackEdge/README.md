# Widget Stack Edge

Samsung Edge panel that shows widgets of ANY installed app, stacked one per row (2x1, 2x2, 2x3, 2x4).

## Build (GitHub Actions)
1. Create a new GitHub repo and upload everything in this folder (keep the `.github` folder).
2. Actions tab > "Build APK" > run (or push). Download the artifact `WidgetStackEdge-apk`.
3. Install the APK. There is no launcher icon by design.

## Use
1. Settings > Display > Edge panels > tick this panel (its name is blank on purpose; look for the preview image).
2. Open the edge panel, tap the small gear (or the "Settings" link in the Edge panels list).
3. "+ Add widget", pick a widget, choose its size chip (2x1 / 2x2 ...), reorder with the arrows.
4. Size & layout sliders control row height, gap, padding and panel height; the green/red line shows how many widgets fit.

## If the panel stays empty
Open the settings screen and read the "Diagnostics" box at the bottom; send it to Claude.

Show a visible name: edit `panel_label` in `app/src/main/res/values/strings.xml`.
