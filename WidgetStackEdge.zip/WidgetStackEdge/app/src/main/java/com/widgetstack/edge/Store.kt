package com.widgetstack.edge

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class Entry(val id: Int, var rows: Int)

object Store {
    private fun p(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    fun entries(c: Context): MutableList<Entry> {
        val out = mutableListOf<Entry>()
        try {
            val a = JSONArray(p(c).getString("entries", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Entry(o.getInt("id"), o.optInt("rows", 1)))
            }
        } catch (e: Exception) {
        }
        return out
    }

    fun save(c: Context, list: List<Entry>) {
        val a = JSONArray()
        for (e in list) a.put(JSONObject().put("id", e.id).put("rows", e.rows))
        p(c).edit().putString("entries", a.toString()).apply()
    }

    fun int(c: Context, k: String, d: Int): Int = p(c).getInt(k, d)
    fun setInt(c: Context, k: String, v: Int) = p(c).edit().putInt(k, v).apply()
    fun bool(c: Context, k: String, d: Boolean): Boolean = p(c).getBoolean(k, d)
    fun setBool(c: Context, k: String, v: Boolean) = p(c).edit().putBoolean(k, v).apply()
    fun str(c: Context, k: String): String = p(c).getString(k, "") ?: ""
    fun setStr(c: Context, k: String, v: String) = p(c).edit().putString(k, v).apply()

    fun ids(c: Context): IntArray =
        str(c, "ids").split(",").mapNotNull { it.toIntOrNull() }.toIntArray()

    fun addIds(c: Context, add: IntArray) {
        val all = ids(c).toMutableSet()
        all.addAll(add.toList())
        setStr(c, "ids", all.joinToString(","))
    }

    fun setLog(c: Context, m: String) = setStr(c, "log", m)
    fun log(c: Context): String = str(c, "log")
}
