package com.widgetstack.edge

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class PanelReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Bridge.init()
        intent.getIntArrayExtra("cocktailIds")?.let { Store.addIds(context, it) }
        val single = intent.getIntExtra("cocktailId", -1)
        if (single >= 0) Store.addIds(context, intArrayOf(single))
        // Panel enabled / shown / updated: rebuild the card from the saved widget list.
        Renderer.refreshPanel(context)
    }
}
