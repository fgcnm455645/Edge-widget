package com.widgetstack.edge

import android.content.ComponentName
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.widget.RemoteViews
import org.lsposed.hiddenapibypass.HiddenApiBypass
import java.lang.reflect.InvocationTargetException

/**
 * Talks to Samsung's edge panel service through reflection, so no Samsung SDK jar is needed.
 */
object Bridge {
    private const val CLS = "com.samsung.android.cocktailbar.CocktailBarManager"
    private var inited = false

    fun init() {
        if (inited) return
        inited = true
        try {
            if (Build.VERSION.SDK_INT >= 28) HiddenApiBypass.addHiddenApiExemptions("L")
        } catch (t: Throwable) {
        }
    }

    private fun manager(ctx: Context): Pair<Class<*>, Any?> {
        val c = Class.forName(CLS)
        val m = c.getMethod("getInstance", Context::class.java).invoke(null, ctx)
        return Pair(c, m)
    }

    fun ids(ctx: Context): IntArray {
        val set = Store.ids(ctx).toMutableSet()
        try {
            val (c, m) = manager(ctx)
            val r = c.getMethod("getCocktailIds", ComponentName::class.java)
                .invoke(m, ComponentName(ctx, PanelReceiver::class.java))
            if (r is IntArray) set.addAll(r.toList())
        } catch (t: Throwable) {
        }
        return set.toIntArray()
    }

    /** Returns null on success, otherwise a short error text. */
    fun update(ctx: Context, id: Int, rv: RemoteViews): String? {
        return try {
            val (c, m) = manager(ctx)
            val i = Int::class.javaPrimitiveType!!
            val comp = ComponentName(ctx, PanelReceiver::class.java)
            try {
                c.getMethod(
                    "updateCocktail", i, i, i,
                    RemoteViews::class.java, RemoteViews::class.java,
                    Bundle::class.java, ComponentName::class.java
                ).invoke(m, id, 0, 0, rv, null, null, comp)
                null
            } catch (e: NoSuchMethodException) {
                c.getMethod(
                    "updateCocktail", i, i, i,
                    RemoteViews::class.java, Bundle::class.java
                ).invoke(m, id, 0, 0, rv, null)
                null
            }
        } catch (e: InvocationTargetException) {
            "id $id: ${e.targetException}"
        } catch (e: Throwable) {
            "id $id: $e"
        }
    }
}
