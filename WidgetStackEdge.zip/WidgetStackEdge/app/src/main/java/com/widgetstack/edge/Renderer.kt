package com.widgetstack.edge

import android.app.PendingIntent
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.TypedValue
import android.view.View
import android.widget.RemoteViews

object Renderer {
    const val HOST_ID = 4242

    /** Host view that only keeps the RemoteViews the widget sent, instead of inflating them. */
    class CaptureView(c: Context) : AppWidgetHostView(c) {
        var captured: RemoteViews? = null
        override fun updateAppWidget(remoteViews: RemoteViews?) {
            captured = remoteViews
        }
    }

    class CaptureHost(c: Context) : AppWidgetHost(c, HOST_ID) {
        override fun onCreateView(
            context: Context,
            appWidgetId: Int,
            appWidget: AppWidgetProviderInfo?
        ): AppWidgetHostView = CaptureView(context)
    }

    fun cellH(c: Context) = Store.int(c, "cell_h", 91)
    fun gap(c: Context) = Store.int(c, "gap", 6)
    fun pad(c: Context) = Store.int(c, "pad", 0)

    fun slotHeight(rows: Int, cell: Int, gap: Int) = rows * cell + (rows - 1) * gap

    fun maxHeightDp(c: Context): Float {
        val dm = c.resources.displayMetrics
        return dm.heightPixels / dm.density * Store.int(c, "panel_pct", 87) / 100f
    }

    fun usedHeightDp(c: Context, entries: List<Entry>, count: Int): Float {
        var used = 0f
        for (i in 0 until count) used += slotHeight(entries[i].rows, cellH(c), gap(c)) + gap(c)
        return used
    }

    /** How many widgets (from the top) fit in the panel height. */
    fun fitCount(c: Context, entries: List<Entry>): Int {
        var used = 0f
        var n = 0
        for (e in entries) {
            val h = slotHeight(e.rows, cellH(c), gap(c)) + gap(c)
            if (used + h > maxHeightDp(c)) break
            used += h
            n++
        }
        return n
    }

    fun settingsIntent(ctx: Context): PendingIntent = PendingIntent.getActivity(
        ctx, 0,
        Intent(ctx, SettingsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    fun build(ctx: Context, log: StringBuilder): RemoteViews {
        val cell = cellH(ctx)
        val gap = gap(ctx)
        val pad = pad(ctx)
        val density = ctx.resources.displayMetrics.density
        val panelW = Store.int(ctx, "panel_w", 169)
        val widthDp = panelW - 2 * pad
        val maxH = maxHeightDp(ctx)

        val awm = AppWidgetManager.getInstance(ctx)
        val host = CaptureHost(ctx.applicationContext)
        val root = RemoteViews(ctx.packageName, R.layout.panel_root)
        val pi = settingsIntent(ctx)

        val px = (pad * density).toInt()
        root.setViewPadding(R.id.stack, px, px, px, px)

        var used = 0f
        var shown = 0
        val entries = Store.entries(ctx)
        for (e in entries) {
            val info = awm.getAppWidgetInfo(e.id)
            if (info == null) {
                log.append("widget ${e.id}: provider missing\n")
                continue
            }
            val h = slotHeight(e.rows, cell, gap)
            if (used + h + gap > maxH) {
                log.append("widget ${e.id}: does not fit, hidden\n")
                break
            }

            val want = "${widthDp}x$h"
            if (Store.str(ctx, "sz_${e.id}") != want) {
                val b = Bundle()
                b.putInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, widthDp)
                b.putInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, widthDp)
                b.putInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, h)
                b.putInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, h)
                try {
                    awm.updateAppWidgetOptions(e.id, b)
                    Store.setStr(ctx, "sz_${e.id}", want)
                } catch (t: Throwable) {
                    log.append("options ${e.id}: $t\n")
                }
            }

            val view = host.createView(ctx.applicationContext, e.id, info) as? CaptureView
            val rv = view?.captured
            if (rv == null) {
                log.append("widget ${e.id}: no content yet\n")
                continue
            }

            val slot = RemoteViews(ctx.packageName, R.layout.slot)
            slot.setViewLayoutHeight(R.id.slot_content, h.toFloat(), TypedValue.COMPLEX_UNIT_DIP)
            slot.setViewLayoutMargin(
                R.id.slot_content, RemoteViews.MARGIN_BOTTOM, gap.toFloat(), TypedValue.COMPLEX_UNIT_DIP
            )
            slot.addView(R.id.slot_content, rv)
            root.addView(R.id.stack, slot)
            used += h + gap
            shown++
        }

        log.append("shown $shown of ${entries.size}\n")
        root.setViewVisibility(R.id.empty, if (shown == 0) View.VISIBLE else View.GONE)
        root.setOnClickPendingIntent(R.id.empty, pi)
        val gear = Store.bool(ctx, "gear", true) || shown == 0
        root.setViewVisibility(R.id.gear, if (gear) View.VISIBLE else View.GONE)
        root.setOnClickPendingIntent(R.id.gear, pi)
        return root
    }

    fun refreshPanel(ctx: Context) {
        Bridge.init()
        val log = StringBuilder()
        val ids = Bridge.ids(ctx)
        if (ids.isEmpty()) {
            Store.setLog(ctx, "Panel is not enabled yet (no panel id).\nEnable it in Settings > Display > Edge panels.")
            return
        }
        try {
            val rv = build(ctx, log)
            for (id in ids) {
                val err = Bridge.update(ctx, id, rv)
                log.append(if (err == null) "panel $id updated\n" else "ERROR $err\n")
            }
        } catch (t: Throwable) {
            log.append("build error: $t\n")
        }
        Store.setLog(ctx, log.toString())
    }
}
