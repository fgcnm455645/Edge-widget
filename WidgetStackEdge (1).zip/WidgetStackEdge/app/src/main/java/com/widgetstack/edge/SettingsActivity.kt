package com.widgetstack.edge

import android.app.Activity
import android.app.AlertDialog
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

class SettingsActivity : Activity() {
    private lateinit var host: AppWidgetHost
    private lateinit var awm: AppWidgetManager
    private lateinit var content: LinearLayout
    private var pendingId = -1
    private var pendingInfo: AppWidgetProviderInfo? = null
    private val handler = Handler(Looper.getMainLooper())

    private val reqBind = 11
    private val reqCfg = 12

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(text: String, size: Float = 14f, color: Int = Color.WHITE, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.setTypeface(null, Typeface.BOLD)
        return t
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        host = AppWidgetHost(this, Renderer.HOST_ID)
        awm = AppWidgetManager.getInstance(this)
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(0xFF111111.toInt())
        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(16), dp(48), dp(16), dp(40))
        scroll.addView(content)
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        Bridge.init()
        build()
    }

    private fun refreshPanelNow() {
        Renderer.refreshPanel(this)
        // widgets get a new size asynchronously; render once more shortly after
        handler.postDelayed({ Renderer.refreshPanel(this) }, 800)
    }

    private fun build() {
        content.removeAllViews()
        content.addView(tv("Widget Stack Edge", 24f, Color.WHITE, true))
        content.addView(
            tv(
                "Enable: Settings > Display > Edge panels, then tick this panel.",
                13f, 0xFFAAAAAA.toInt()
            )
        )

        val entries = Store.entries(this)
        val fit = Renderer.fitCount(this, entries)
        val maxH = Renderer.maxHeightDp(this).toInt()
        val used = Renderer.usedHeightDp(this, entries, fit).toInt()
        val status = tv(
            "Fits: $fit of ${entries.size} widgets  (using $used of $maxH dp)",
            14f, if (fit < entries.size) 0xFFFF8A80.toInt() else 0xFF80E27E.toInt()
        )
        status.setPadding(0, dp(12), 0, dp(4))
        content.addView(status)

        // widget list
        for (i in entries.indices) addRow(entries, i, i >= fit)

        val add = Button(this)
        add.text = "+ Add widget"
        add.setOnClickListener { showPicker() }
        content.addView(add)

        // size / layout settings
        val h = tv("Size & layout", 18f, Color.WHITE, true)
        h.setPadding(0, dp(20), 0, dp(4))
        content.addView(h)
        slider("Row height (1 cell)", "cell_h", 60, 140, 91, " dp")
        slider("Gap between widgets", "gap", 0, 16, 6, " dp")
        slider("Card padding", "pad", 0, 16, 0, " dp")
        slider("Panel height", "panel_pct", 50, 100, 87, " % of screen")
        slider("Panel width (for widget sizing)", "panel_w", 120, 260, 169, " dp")

        val sw = Switch(this)
        sw.text = "Show settings button inside the panel"
        sw.setTextColor(Color.WHITE)
        sw.isChecked = Store.bool(this, "gear", true)
        sw.setOnCheckedChangeListener { _, checked ->
            Store.setBool(this, "gear", checked)
            refreshPanelNow()
        }
        sw.setPadding(0, dp(12), 0, dp(12))
        content.addView(sw)

        val refresh = Button(this)
        refresh.text = "Refresh panel"
        refresh.setOnClickListener {
            refreshPanelNow()
            handler.postDelayed({ build() }, 900)
        }
        content.addView(refresh)

        val d = tv("Diagnostics", 16f, Color.WHITE, true)
        d.setPadding(0, dp(20), 0, dp(4))
        content.addView(d)
        val log = tv(Store.log(this).ifEmpty { "(nothing yet)" }, 12f, 0xFFAAAAAA.toInt())
        log.setTextIsSelectable(true)
        content.addView(log)
    }

    private fun addRow(entries: MutableList<Entry>, i: Int, hidden: Boolean) {
        val e = entries[i]
        val info = awm.getAppWidgetInfo(e.id)

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, dp(8), 0, dp(8))

        val icon = ImageView(this)
        try {
            if (info != null) icon.setImageDrawable(info.loadIcon(this, 0))
        } catch (t: Throwable) {
        }
        row.addView(icon, LinearLayout.LayoutParams(dp(36), dp(36)))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(10), 0, dp(6), 0)
        val name = if (info != null) info.loadLabel(packageManager) else "(widget removed)"
        col.addView(
            tv(
                if (hidden) "$name  - does not fit" else name,
                15f, if (hidden) 0xFFFF8A80.toInt() else Color.WHITE
            )
        )
        val chips = LinearLayout(this)
        chips.orientation = LinearLayout.HORIZONTAL
        for (r in 1..4) {
            val chip = tv("2x$r", 13f)
            chip.setPadding(dp(10), dp(5), dp(10), dp(5))
            chip.setBackgroundColor(if (e.rows == r) 0xFF3D5AFE.toInt() else 0xFF2A2A2A.toInt())
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.setMargins(0, dp(4), dp(6), 0)
            chip.setOnClickListener {
                e.rows = r
                Store.save(this, entries)
                refreshPanelNow()
                build()
            }
            chips.addView(chip, lp)
        }
        col.addView(chips)
        row.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        fun btn(label: String, action: () -> Unit) {
            val b = tv(label, 20f)
            b.setPadding(dp(10), dp(6), dp(10), dp(6))
            b.setOnClickListener { action() }
            row.addView(b)
        }
        btn("\u25B2") {
            if (i > 0) {
                entries.add(i - 1, entries.removeAt(i))
                Store.save(this, entries)
                refreshPanelNow()
                build()
            }
        }
        btn("\u25BC") {
            if (i < entries.size - 1) {
                entries.add(i + 1, entries.removeAt(i))
                Store.save(this, entries)
                refreshPanelNow()
                build()
            }
        }
        btn("\u2715") {
            try {
                host.deleteAppWidgetId(e.id)
            } catch (t: Throwable) {
            }
            entries.removeAt(i)
            Store.save(this, entries)
            refreshPanelNow()
            build()
        }
        content.addView(row)
        val line = View(this)
        line.setBackgroundColor(0xFF2A2A2A.toInt())
        content.addView(line, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1))
    }

    private fun slider(title: String, key: String, min: Int, max: Int, def: Int, unit: String) {
        val cur = Store.int(this, key, def)
        val label = tv("$title: $cur$unit", 14f)
        label.setPadding(0, dp(10), 0, 0)
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = cur - min
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                label.text = "$title: ${p + min}$unit"
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}

            override fun onStopTrackingTouch(s: SeekBar?) {
                Store.setInt(this@SettingsActivity, key, (s?.progress ?: 0) + min)
                refreshPanelNow()
                build()
            }
        })
        content.addView(label)
        content.addView(sb)
    }

    private fun appLabel(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg
    }

    private fun showPicker() {
        val all = awm.installedProviders.sortedBy {
            (appLabel(it.provider.packageName) + it.loadLabel(packageManager)).lowercase()
        }
        val names = all.map {
            val cw = (it.minWidth + 30) / 70
            val ch = (it.minHeight + 30) / 70
            "${appLabel(it.provider.packageName)} - ${it.loadLabel(packageManager)}  (${cw}x$ch)"
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Choose a widget")
            .setItems(names) { _, which -> startBind(all[which]) }
            .show()
    }

    private fun startBind(info: AppWidgetProviderInfo) {
        val id = host.allocateAppWidgetId()
        pendingId = id
        pendingInfo = info
        if (awm.bindAppWidgetIdIfAllowed(id, info.provider)) {
            afterBind()
        } else {
            val i = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
            i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider)
            startActivityForResult(i, reqBind)
        }
    }

    private fun afterBind() {
        val info = pendingInfo ?: return
        if (info.configure != null) {
            try {
                host.startAppWidgetConfigureActivityForResult(this, pendingId, 0, reqCfg, null)
            } catch (t: Throwable) {
                finishAdd()
            }
        } else {
            finishAdd()
        }
    }

    private fun finishAdd() {
        val info = pendingInfo ?: return
        val list = Store.entries(this)
        val cellsH = (info.minHeight + 30) / 70
        list.add(Entry(pendingId, if (cellsH >= 2) 2 else 1))
        Store.save(this, list)
        pendingId = -1
        pendingInfo = null
        refreshPanelNow()
        build()
    }

    private fun cancelAdd() {
        if (pendingId >= 0) {
            try {
                host.deleteAppWidgetId(pendingId)
            } catch (t: Throwable) {
            }
        }
        pendingId = -1
        pendingInfo = null
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            reqBind -> if (resultCode == RESULT_OK) afterBind() else cancelAdd()
            reqCfg -> if (resultCode == RESULT_OK) finishAdd() else cancelAdd()
        }
    }
}
